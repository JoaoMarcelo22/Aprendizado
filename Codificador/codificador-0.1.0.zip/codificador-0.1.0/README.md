# Challenge-Oracle-One
Desafios da semana 1 e 2 , fazer uma pagina que faça a criptografia e descriptografia, CSS ,HTML e JavaScript são as tecnologias utilizadas. 
